<?php
/* settings/database.php */

return [
    'mysql' => [
        'dbdriver' => 'mysql',
        'username' => 'root',
        'password' => '',
        'dbname' => 'sms',
        'prefix' => 'app'
    ],
    'tables' => [
        'user' => 'user',
        'personnel' => 'personnel',
        'student' => 'student',
        'course' => 'course',
        'grade' => 'grade',
        'category' => 'category',
        'edocument' => 'edocument',
        'edocument_download' => 'edocument_download'
    ]
];
