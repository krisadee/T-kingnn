<?php
/**
 * @filesource modules/personnel/views/setup.php
 *
 * @copyright 2016 Goragod.com
 * @license https://www.kotchasan.com/license/
 *
 * @see https://www.kotchasan.com/
 */

namespace Personnel\Setup;

use Kotchasan\DataTable;
use Kotchasan\Http\Request;
use Kotchasan\Language;

/**
 * module=personnel-setup
 *
 * @author Goragod Wiriya <admin@goragod.com>
 *
 * @since 1.0
 */
class View extends \Gcms\View
{
    /**
     * @var object
     */
    private $category;
    /**
     * @var object
     */
    private $school_category;
    /**
     * @var array
     */
    private $personnel_status;

    /**
     * แสดงรายการบุคลากร สำหรับผู้ดูแล
     *
     * @param Request $request
     *
     * @return string
     */
    public function render(Request $request)
    {
        // สำหรับปุ่ม export
        $export = [];
        // สถานะบุคลากร
        $this->personnel_status = Language::get('PERSONNEL_STATUS');
        $this->school_category = \School\Category\Model::init();
        // เตรียมข้อมูลสำหรับใส่ลงในตาราง
        $fields = ['name', 'active'];
        $headers = [
            'name' => [
                'text' => '{LNG_Name}',
                'sort' => 'name'
            ],
            'active' => [
                'text' => '{LNG_Status}',
                'class' => 'center',
                'sort' => 'active'
            ]
        ];
        $cols = [
            'order' => [
                'class' => 'center'
            ],
            'id' => [
                'class' => 'center'
            ],
            'active' => [
                'class' => 'center'
            ],
            'class' => [
                'class' => 'center'
            ]
        ];
        $filters = [];
        // หมวดหมู่
        $this->category = \Index\Category\Model::init();
        foreach ($this->category->typies() as $type) {
            $export[$type] = $request->request($type)->toInt();
            $fields[] = $type;
            $filters[$type] = [
                'name' => $type,
                'text' => $this->category->name($type),
                'options' => [0 => '{LNG_all items}'] + $this->category->toSelect($type),
                'default' => 0,
                'value' => $export[$type]
            ];
            $headers[$type] = [
                'text' => $this->category->name($type),
                'class' => 'center',
                'sort' => $type
            ];
            $cols[$type] = [
                'class' => 'center'
            ];
        }
        $fields[] = 'class';
        $fields[] = 'room';
        $headers['class'] = [
            'text' => '{LNG_Class teacher}',
            'class' => 'center'
        ];
        $fields[] = 'order';
        $headers['order'] = [
            'text' => '{LNG_Order}',
            'class' => 'center',
            'sort' => 'order'
        ];
        $fields[] = 'id';
        $headers['id'] = [
            'text' => '{LNG_Image}',
            'class' => 'center'
        ];
        $export['active'] = $request->request('active', -1)->toInt();
        $filters['active'] = [
            'name' => 'active',
            'text' => '{LNG_Status}',
            'options' => [-1 => '{LNG_all items}'] + $this->personnel_status,
            'default' => -1,
            'value' => $export['active']
        ];
        // URL สำหรับส่งให้ตาราง
        $uri = $request->createUriWithGlobals(WEB_URL.'index.php');
        // ตาราง
        $table = new DataTable([
            /* Uri */
            'uri' => $uri,
            /* Model */
            'model' => \Personnel\User\Model::toDataTable(),
            /* ฟิลด์ที่กำหนด (หากแตกต่างจาก Model) */
            'fields' => $fields,
            /* รายการต่อหน้า */
            'perPage' => $request->cookie('person_perPage', 30)->toInt(),
            /* เรียงลำดับ */
            'sort' => $request->cookie('person_sort', 'id DESC')->toString(),
            /* ฟังก์ชั่นจัดรูปแบบการแสดงผลแถวของตาราง */
            'onRow' => [$this, 'onRow'],
            /* ตั้งค่าการกระทำของของตัวเลือกต่างๆ ด้านล่างตาราง ซึ่งจะใช้ร่วมกับการขีดถูกเลือกแถว */
            'action' => 'index.php/personnel/model/setup/action',
            'actionCallback' => 'dataTableActionCallback',
            'actions' => [
                [
                    'id' => 'action',
                    'class' => 'ok',
                    'text' => '{LNG_With selected}',
                    'options' => [
                        'delete' => '{LNG_Delete}'
                    ]
                ],
                [
                    'class' => 'button orange icon-excel border',
                    'id' => 'export&'.http_build_query($export),
                    'text' => '{LNG_Download} {LNG_Personnel list}'
                ]
            ],
            /* คอลัมน์ที่สามารถค้นหาได้ */
            'searchColumns' => ['name'],
            /* ตัวเลือกด้านบนของตาราง ใช้จำกัดผลลัพท์การ query */
            'filters' => $filters,
            /* คอลัมน์ที่ไม่ต้องการแสดงผล */
            'hideColumns' => ['room'],
            /* ส่วนหัวของตาราง และการเรียงลำดับ (thead) */
            'headers' => $headers,
            /* รูปแบบการแสดงผลของคอลัมน์ (tbody) */
            'cols' => $cols,
            /* ปุ่มแสดงในแต่ละแถว */
            'buttons' => [
                'view' => [
                    'class' => 'icon-info button brown notext',
                    'id' => ':id',
                    'title' => '{LNG_Details of} {LNG_Personnel}'
                ],
                'edit' => [
                    'class' => 'icon-edit button green notext',
                    'href' => $uri->createBackUri(['module' => 'personnel-write', 'id' => ':id']),
                    'title' => '{LNG_Edit}'
                ]
            ],
            /* ปุ่มเพิม */
            'addNew' => [
                'class' => 'float_button icon-new',
                'href' => $uri->createBackUri(['module' => 'personnel-write', 'id' => 0]),
                'title' => '{LNG_Add}'
            ]
        ]);
        // save cookie
        setcookie('person_perPage', $table->perPage, time() + 3600 * 24 * 365, '/');
        // Javascript
        $table->script('initPerson("datatable");');
        // คืนค่า HTML
        return $table->render();
    }

    /**
     * จัดรูปแบบการแสดงผลในแต่ละแถว
     *
     * @param array $item
     *
     * @return array
     */
    public function onRow($item, $o, $prop)
    {
        foreach ($this->category->typies() as $type) {
            $item[$type] = $this->category->get($type, $item[$type]);
        }
        $item['order'] = '<label><input type=number size=5 id=order_'.$item['id'].' value="'.$item['order'].'"></label>';
        if ($item['active'] == 0) {
            $item['active'] = '<a id=active_0_'.$item['id'].' class="icon-valid disabled" title="'.$this->personnel_status[0].'"></a>';
        } else {
            $item['active'] = '<a id=active_1_'.$item['id'].' class="icon-valid access" title="'.$this->personnel_status[1].'"></a>';
        }
        if (is_file(ROOT_PATH.DATA_FOLDER.'personnel/'.$item['id'].self::$cfg->stored_img_type)) {
            $item['id'] = '<img src="'.WEB_URL.DATA_FOLDER.'personnel/'.$item['id'].self::$cfg->stored_img_type.'" style="max-height:50px" alt=thumbnail>';
        } else {
            $item['id'] = '<img src="'.WEB_URL.'modules/personnel/img/noimage.jpg" style="max-height:50px" alt=thumbnail>';
        }
        $item['class'] = $this->school_category->get('class', $item['class']).$this->school_category->get('room', $item['room'], '/');
        return $item;
    }
}
